
<?php $__env->startSection('page_title'); ?> All Orders <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
 
<link href="<?php echo e(asset('/assets/admin/vendors/DataTables/datatables.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 
<div class="page-heading">
<?php echo $__env->make('admin.section.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="page-content fade-in-up">
    <div class="ibox">
        <div class="ibox-head">
            <div class="ibox-title">All Orders</div>
            <div>
            </div>
        </div>
         

        <div class="ibox-body">
            <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>Order Id</th>
                        <th>Customer Name</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Order Detail/ Change Status/ Delete</th>
                    </tr>
                </thead>
                <tbody>

                    
                    <?php if($orders->count()): ?>
                    
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="category_row<?php echo e($order_data->id); ?>">
                        <td> #<?php echo e($order_data->id); ?></td>
                        <td><?php echo e(@$order_data->client->name); ?></td>
                        <td><?php echo e(Carbon\Carbon::parse($order_data->created_at)->format('Y,M d')); ?></td>
                        <td><span class="badge badge-pill badge-warning"><?php echo e($order_data->status); ?></span>
                            </td>
                        <td>
                            <ul class="action_list">
                                <li>
                                    <a href="<?php echo e(route('orders.show',$order_data->id)); ?>" data- class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                    
                                </li>
                                <li>
                                    <button class="btn btn-success btn-sm changeOrderStatus" data-id="<?php echo e($order_data->id); ?>" data-title="<?php echo e($order_data->title); ?>"><i class="fa fa-pencil"></i></button>
                                </li>
                                <li>
                                    <form action="<?php echo e(route('orders.destroy', $order_data->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button onclick="return confirm('Are you sure you want to delete this Order?')"
                                        class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                    </form>
                                </li>
                            </ul>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="8">
                            You do not have any Catogory yet.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
                 
            </table>
        </div>
    </div>
     
</div>
<?php echo $__env->make('admin.order.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('/assets/admin/vendors/DataTables/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/assets/admin/js/sweetalert.js')); ?>" type="text/javascript"></script>
<script type="text/javascript">
    $(function() {
        $('#example-table').DataTable({
            pageLength: 25,
        });
    })
</script>
<script>
    

function FailedResponseFromDatabase(message){
    html_error = "";
    $.each(message, function(index, message){
        html_error += '<p class ="error_message text-left"> <span class="fa fa-times"></span> '+message+ '</p>';
    });
    Swal.fire({
        type: 'error',
        title: 'Oops...',
        html:html_error ,
        confirmButtonText: 'Close',
        timer: 10000
    });
}
function DataSuccessInDatabase(message){
    Swal.fire({
        // position: 'top-end',
        type: 'success',
        title: 'Done',
        html: message ,
        confirmButtonText: 'Close',
        timer: 10000
    });
}
</script>
<script>
    $(document).ready(function(){
        $('.changeOrderStatus').click(function(e){
                e.preventDefault();
                id=$(this).data('id');
                $('#myModal').modal('show');
                $("#myModal #title").val( id );
            });
        
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\shery-treding\shrey-trading\resources\views/admin/order/list.blade.php ENDPATH**/ ?>