<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <link rel="shortcut icon" rel="icon" href="<?php echo e(asset('/assets/front/images/icon.png')); ?>" type="image/gif" />
    <title>  <?php echo $__env->yieldContent('page_title'); ?> | Shray Trading | Best Ecommerce Trademark</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="<?php echo e(asset('/assets/admin/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/assets/admin/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/assets/admin/vendors/themify-icons/css/themify-icons.css')); ?>" rel="stylesheet" />
    <!-- PLUGINS STYLES-->
    <link href="<?php echo e(asset('/assets/admin/vendors/jvectormap/jquery-jvectormap-2.0.3.css')); ?>" rel="stylesheet" />
    <!-- THEME STYLES-->
    <link href="<?php echo e(asset('/assets/admin/css/main.min.css')); ?>" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <!-- PAGE LEVEL STYLES-->
    <?php echo $__env->yieldContent('styles'); ?>
    <script src="<?php echo e(asset('/assets/admin/vendors/jquery/dist/jquery.min.js')); ?>" type="text/javascript"></script>
</head>

<body class="fixed-navbar">
    <div class="page-wrapper">

<header class="header">
    <div class="page-brand">
        <a class="link" href="/">
            <span class="brand">Shray
                <span class="brand-tip">Trading</span>
            </span>
            <span class="brand-mini">ST</span>
        </a>
    </div>
    <div class="flexbox flex-1">
        <!-- START TOP-LEFT TOOLBAR-->
        <ul class="nav navbar-toolbar">
            <li>
                <a class="nav-link sidebar-toggler js-sidebar-toggler"><i class="ti-menu"></i></a>
            </li>
             
        </ul>
        <!-- END TOP-LEFT TOOLBAR-->
        <!-- START TOP-RIGHT TOOLBAR-->
        <ul class="nav navbar-toolbar">
            
             
            <li class="dropdown dropdown-user">
                <a class="nav-link dropdown-toggle link" data-toggle="dropdown">
                    <img src="<?php echo e(asset('/assets/admin/images/admin-avatar.png')); ?>" />
                    <span></span><i class="fa fa-angle-down m-l-5"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-right">
                    
                    <li class="dropdown-divider"></li>
                    <?php if(auth()->user()): ?>
                    <a class="dropdown-item" href="<?php echo e(route('admin.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fa fa-power-off"></i>Logout
                    </a>
                    <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                    <?php else: ?>
                    <a class="dropdown-item" href="<?php echo e(route('client.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fa fa-power-off"></i>Logout
                    </a>
                    <form id="logout-form" action="<?php echo e(route('client.logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                    <?php endif; ?>
                </ul>
            </li>
        </ul>
        <!-- END TOP-RIGHT TOOLBAR-->
    </div>
</header><?php /**PATH F:\shery-treding\shrey-trading\resources\views/admin/section/header.blade.php ENDPATH**/ ?>