    <!-- START HEADER-->
    <?php echo $__env->make('admin.section.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END HEADER-->
        <!-- START SIDEBAR-->
        <?php echo $__env->make('admin.section.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">
            <!-- START PAGE CONTENT-->
            <?php echo $__env->yieldContent('content'); ?>
            <!-- END PAGE CONTENT-->
            <?php echo $__env->make('admin.section.copy-right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
   
   
        <?php echo $__env->make('admin.section.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('scripts'); ?><?php /**PATH F:\shery-treding\shrey-trading\resources\views/layouts/admin.blade.php ENDPATH**/ ?>