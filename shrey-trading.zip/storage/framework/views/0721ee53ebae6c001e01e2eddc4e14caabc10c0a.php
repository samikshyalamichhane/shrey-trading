
<?php $__env->startSection('page_title'); ?> Admin <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
 
<link href="<?php echo e(asset('/assets/admin/vendors/DataTables/datatables.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div id="app">
<?php if(auth()->guard('client')->user()): ?>
<div class="page-content fade-in-up">
    <div class="col-sm-12">
        <div class="row">
        <?php if(auth()->user()): ?>
            <div class="col-12">
            <a href="<?php echo e(route('users.index')); ?>" target="_blank" style="color:white">
                <div class="card text-white bg-primary" style="margin-bottom:2rem">
                    <div class="card-body card-body pb-0 mb-4 d-flex justify-content-between align-items-start">
                        <div>
                            <div class="text-value-lg" style="font-size: 1.3125rem;"><?php echo e(count($users)); ?></div>
                            <div>
                            Total Users</div>
                        </div>
                    </div>
                </div>
                </a>
            </div>
            <!-- /.col-->
            <div class="col-12">
            <a href="<?php echo e(route('clients.index')); ?>" target="_blank" style="color:white">
                <div class="card text-white bg-info" style="margin-bottom:2rem">
                    <div class="card-body card-body pb-0 mb-4 d-flex justify-content-between align-items-start">
                        <div>
                            <div class="text-value-lg" style="font-size: 1.3125rem;"><?php echo e(count($clients)); ?></div>
                            <div>Total Clients</div>
                        </div>
                    </div>
                </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if(auth()->guard('client')->user()): ?>
            <!-- /.col-->
            <div class="col-md-4"> 
            <a href="<?php echo e(route('products.index')); ?>" target="_blank" style="color:white">
                <div class="card text-white bg-info" style="margin-bottom:2rem">
                    <div class="card-body card-body pb-0 mb-4 d-flex justify-content-between align-items-start">
                        <div>
                            <div class="text-value-lg" style="font-size: 1.3125rem;"><?php echo e(count($myProducts)); ?></div>
                            <div>My Products</div>
                        </div>
                    </div>
                </div>
            </a>
            </div>
            <?php endif; ?>
            <?php if(auth()->guard('client')->user() || auth()->user()): ?>
            <div class="col-md-4">
            <a href="<?php echo e(route('products.index')); ?>" target="_blank" style="color:white">
                <div class="card text-white bg-primary" style="margin-bottom:2rem">
                    <div class="card-body card-body pb-0 mb-4 d-flex justify-content-between align-items-start">
                        <div>
                            <div class="text-value-lg" style="font-size: 1.3125rem;"><?php echo e(count($products)); ?></div>
                            <div>Total Products</div>
                        </div>
                    </div>
                </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if(auth()->guard('client')->user()): ?>
            <div class="col-md-4">
            <a href="<?php echo e(route('orders.index')); ?>" target="_blank" style="color:white">
                <div class="card text-white bg-warning" style="margin-bottom:2rem">
                    <div class="card-body card-body pb-0 mb-4 d-flex justify-content-between align-items-start">
                        <div>
                            <div class="text-value-lg" style="font-size: 1.3125rem;"><?php echo e(count($orders)); ?></div>
                            <div>Total Orders</div>
                        </div>
                    </div>
                </div>
                </a>
            </div>
            <?php endif; ?>
        </div>
        <div class="row newcartlist">
            <div class="col-sm-12">
                <div class="samebg">
                    <my-products :myproducts="<?php echo e(json_encode($myProducts)); ?>" :products="<?php echo e(json_encode($products)); ?>"/>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php if(auth()->user()): ?>
<div class="page-content fade-in-up">
    <div class="ibox col-sm-12">
        <div class="row">
            <div class="ibox-head col-sm-6">
                <div class="ibox-title">
                    New Orders
                </div>
            </div>
            <div class="ibox-body col-sm-12">
                <table id="example-table3" class="table table-responsive table-hover" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>S.N.</th>
                            <th>Ordered By</th>
                            <th>Date </th>
                            <th>Action</th>

                        </tr>
                    </thead>
                    <tbody>

                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_key => $order_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>#<?php echo e($order_data->id); ?></td>
                            <td><?php echo e(@$order_data->client->name); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($order_data->created_at)->format('Y,M d')); ?></td>
                            <td>
                                <ul class="action_list">
                                    <li>
                                        <a href="<?php echo e(route('orders.show',$order_data->id)); ?>" data- class="btn btn-info btn-md"><i class="fa fa-eye"></i></a>

                                    </li>
                                </ul>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8">
                                You do not have any data yet.
                            </td>
                        </tr>
                        <?php endif; ?>

                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(mix('js/app.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="<?php echo e(asset('/assets/admin/vendors/DataTables/datatables.min.js')); ?>" type="text/javascript"></script>
<script type="text/javascript">
    $(function() {
        $('#example-table').DataTable({
            pageLength: 25,
        });
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\shery-treding\shrey-trading\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>