
<?php $__env->startSection('page_title'); ?> All Products <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
 
<link href="<?php echo e(asset('/assets/admin/vendors/DataTables/datatables.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 
<div class="page-heading">
<?php echo $__env->make('admin.section.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="page-content fade-in-up">
    <div class="ibox">
        <div class="ibox-head">
            <div class="ibox-title">All Products</div>
            <div>
                <a class="btn btn-info btn-md" href="<?php echo e(route('products.create')); ?>">New Product</a>
            </div>
            
        </div>
         

        <div class="ibox-body">
            <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                <thead>
                    <tr class="border-0">
                        <th>SN</th>
                        <th>Name</th>
                        <th>Code</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="sortable">
                    <?php if( isset($products)): ?>
                    
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class='clickable-row' data-href="<?php echo e(route('products.edit', $product_data->id)); ?>" id="<?php echo e($product_data->id); ?>">
                        
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($product_data->name); ?></td>
                            <td><?php echo e($product_data->code); ?></td>
                            <td><?php echo e($product_data->price); ?></td>
                             
                            <td><?php echo $product_data->publish?'<span
                                        class="badge badge-pill badge-success">Active</span>':'<span
                                        class="badge badge-pill badge-warning">Inactive</span>'; ?>

                            </td>
                            <td>
                                <ul class="action_list">
                                    <li>
                                        <a href="<?php echo e(route('products.edit', $product_data->id)); ?>" data- class="btn btn-info btn-md"><i class="fa fa-edit"></i></a>
                                    </li>
              
                                    <li>
                                        <form action="<?php echo e(route('products.destroy', $product_data->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button onclick="return confirm('Are you sure you want to delete this Product?')" class="btn btn-danger">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </form>
                                    </li>
                             
                            </ul>
                                 
                            </td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="8">
                            You do not have any Products  yet.
                        </td>
                    </tr>
                    <?php endif; ?>


                     
                </tbody>
                 
            </table>
        </div>
    </div>
     
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('/assets/admin/vendors/DataTables/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/assets/admin/js/sweetalert.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/assets/admin/js/jquery-ui.js')); ?>"></script>
<script type="text/javascript">
      $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(function() {
        $('#example-table').DataTable({
            pageLength: 500,
        });
    })
    $("#sortable").sortable({
              stop: function(){
                $.map($(this).find('tr'), function(el) {
                  var itemID = el.id;
                  var itemIndex = $(el).index();
                  $.ajax({
                    url:"",
                    method:"post",
                     data: {itemID:itemID, itemIndex: itemIndex},
                    success:function(data){
                      
                    }
                  })
                });
              }
            });
</script>
<script>
    $(document).ready(function(){
    })

function FailedResponseFromDatabase(message){
    html_error = "";
    $.each(message, function(index, message){
        html_error += '<p class ="error_message text-left"> <span class="fa fa-times"></span> '+message+ '</p>';
    });
    Swal.fire({
        type: 'error',
        title: 'Oops...',
        html:html_error ,
        confirmButtonText: 'Close',
        timer: 10000
    });
}
function DataSuccessInDatabase(message){
    Swal.fire({
        // position: 'top-end',
        type: 'success',
        title: 'Done',
        html: message ,
        confirmButtonText: 'Close',
        timer: 10000
    });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\shery-treding\shrey-trading\resources\views/admin/product/list.blade.php ENDPATH**/ ?>