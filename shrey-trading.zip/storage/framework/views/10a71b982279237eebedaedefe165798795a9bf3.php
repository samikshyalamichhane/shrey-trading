<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<script>
    setTimeout(function(){
        $('.alert').slideUp('slow');
    }, 7000);
</script><?php /**PATH F:\shery-treding\shrey-trading\resources\views/admin/section/notifications.blade.php ENDPATH**/ ?>