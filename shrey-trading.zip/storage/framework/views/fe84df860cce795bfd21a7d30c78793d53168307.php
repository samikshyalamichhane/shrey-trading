<nav class="page-sidebar" id="sidebar">
    <div id="sidebar-collapse">
        <div class="admin-block d-flex">
            <div>
                <img src="<?php echo e(asset('/assets/admin/images/admin-avatar.png')); ?>" width="45px" />
            </div>
            <div class="admin-info">
                <div class="font-strong"></div>
            </div>
        </div>
        <ul class="side-menu metismenu">
            <li>
                <a class="active" href="<?php echo e(route('dashboard')); ?>">
                    <!--<i class="sidebar-item-icon fa fa-th-large"></i>-->
                    <i class="sidebar-item-icon fa fa-tachometer" aria-hidden="true"></i>
                    <span class="nav-label">Dashboard</span>
                </a>
            </li>
            <?php if(auth()->user()): ?>
            <li>
                <a href="javascript:;">
                     <i class="sidebar-item-icon fa fa-user-circle-o" aria-hidden="true"></i>
                    <span class="nav-label">Users</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <li>
                        <a href="<?php echo e(route('users.create')); ?>">
                            <span class="fa fa-plus"></span>
                            Add User
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('users.index')); ?>">
                            <span class="fa fa-circle-o"></span>
                            All Users
                        </a>
                    </li>

                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-users" aria-hidden="true"></i>
                    <span class="nav-label">Clients</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <li>
                        <a href="<?php echo e(route('clients.create')); ?>">
                            <span class="fa fa-plus"></span>
                            Add Clients
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('clients.index')); ?>">
                            <span class="fa fa-circle-o"></span>
                            All Clients
                        </a>
                    </li>

                </ul>
            </li>
            <?php endif; ?>
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-shopping-cart" aria-hidden="true"></i>
                    <span class="nav-label">Products</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <?php if(auth()->user()): ?>
                    <li>
                        <a href="<?php echo e(route('products.create')); ?>">
                            <span class="fa fa-plus"></span>
                            Add Product
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if(auth()->guard('client')->user() || auth()->user()): ?>
                    <li>
                        <a href="<?php echo e(route('products.index')); ?>">
                            <span class="fa fa-circle-o"></span>
                            All Products
                        </a>
                    </li>
                    <?php endif; ?>

                </ul>
            </li>

            <li>
                <a href="javascript:;">
                    
                    <i class="sidebar-item-icon fa fa-shopping-bag" aria-hidden="true"></i>
                    <span class="nav-label">Orders</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <?php if(auth()->user()): ?>
                    <li>
                        <a href="<?php echo e(route('orders.index')); ?>">
                            <span class="fa fa-plus"></span>
                            All Orders
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if(auth()->guard('client')->user()): ?>
                    <li>
                        <a href="<?php echo e(route('orders.index')); ?>">
                            <span class="fa fa-circle-o"></span>
                            My Orders
                        </a>
                    </li>
                    <?php endif; ?>

                </ul>
            </li>
           
        </ul>
    </div>
</nav><?php /**PATH F:\shery-treding\shrey-trading\resources\views/admin/section/left-sidebar.blade.php ENDPATH**/ ?>