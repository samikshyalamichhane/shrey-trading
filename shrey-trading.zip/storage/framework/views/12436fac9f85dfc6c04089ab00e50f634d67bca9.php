<table id="example-table1" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>S.N.</th>
            <th>Products</th>
            <th>Code </th>


        </tr>
    </thead>
    <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_key => $all_cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e(++$cart_key); ?></td>
            <td><?php echo e($all_cart->name); ?></td>
            <td><?php echo e($all_cart->code); ?></td>
            <td>
                <div class="cart_list">

                    <div class="qty-wrapper">
                        <button class="minus"  data-product_id="<?php echo e($all_cart->id); ?>">-</button>
                        <input type="text" name="quantity" class="qty-input" value="0">
                        <button class="plus" data-product_id="<?php echo e($all_cart->id); ?>">+</button>
                        <!--<button class="btn category__card__body__cart-btn add_cart_btn list_cart_btn" data-product_id="<?php echo e($all_cart->id); ?>" data-quantity="1" data-type="plus" onclick="addToCart(this)"><span><i class="fa fa-cart-plus" aria-hidden="true"></i></span>add to cart</button>-->

                    </div>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="8">
                You do not have any data yet.
            </td>
        </tr>
        <?php endif; ?>

    </tbody>


</table>

<script>
// $('#search').on('keyup', function(e){
//     e.preventDefault()
    
//     search();
// });
// search();
// function search() {
//     var a = $('#search').val();
//         $.ajax({
//             type: 'GET',
//             data: {
//                     a: a
//                 },
//             url: '<?php echo e(route('searchProduct')); ?>',
//             success: function(response) {
//                 $('#appendProducts').html(response.html)
//             },
//             error: function(error) {
//                 $('#notification-bar').text('An error occurred');
//             }
//         });
//     }

    // search()
    // $.ajaxSetup({
    //     headers: {
    //         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    //     }
    // });
// function search(){
//      var keyword = $('#search').val();
//      $.post('<?php echo e(route("searchProduct")); ?>',
//       {
//          _token: $('meta[name="csrf-token"]').attr('content'),
//          keyword:keyword
//        },
//        success: function(response) {
//                 console.log(response.message)
//                 $('#appendProducts').html(response.html)
//             },
//             error: function(error) {
//                 $('#notification-bar').text('An error occurred');
//             }
// );
// }

</script><?php /**PATH F:\shery-treding\shrey-trading\resources\views/admin/product/productstable.blade.php ENDPATH**/ ?>