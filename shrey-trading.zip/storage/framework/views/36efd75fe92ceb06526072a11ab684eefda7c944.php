
<?php $__env->startSection('page_title'); ?> Add Client <?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>
 
<?php $__env->startSection('content'); ?>
 

<div class="page-content fade-in-up">
    <div class="ibox">
        <div class="ibox-head">
            <div class="ibox-title">Add user</div>
            <div>
                <a class="btn btn-info btn-md" href="<?php echo e(route('clients.index')); ?>">All clients List</a>
            </div>
        </div>
    </div>
    <div class="ibox">
    <?php if($errors->any()): ?>
<div class="alert alert-danger">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    <p><strong>Opps Something went wrong</strong></p>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
</div>
<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible">
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
</button>
<?php echo Session::get('success'); ?>

</div>
<?php endif; ?>
<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible">
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
</button>
<?php echo Session::get('error'); ?>

</div>
<?php endif; ?>
    </div>

    <form class="form form-responsive form-horizontal" action="<?php echo e(route('clients.update', $user_info->id)); ?>" enctype="multipart/form-data" method="post">
            <input type="hidden" name="_method" value="PUT">   
    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-9 col-md-9 col-12">
                    <div class="ibox">
                        <div class="ibox-head">
                            <div class="ibox-title">Clients Information</div>
                            <div class="ibox-tools">
                            </div>
                        </div>
                        <div class="ibox-body">
                            
                            <div class="row">
                                <div class="col-lg-12 col-sm-12 form-group">
                                    <label> Name</label>
                                    <input class="form-control" type="text" value="<?php echo e((@$user_info->name) ?  @$user_info->name: old('name')); ?>" name="name" placeholder=" Name Here">
                                    <?php if($errors->has('name')): ?>
                                    <span class=" alert-danger"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6 col-sm-6 form-group">
                                    <label>Email</label>
                                    <input class="form-control" type="text" value="<?php echo e((@$user_info->email) ?  @$user_info->email: old('email')); ?>" name="email" placeholder="Email Here">
                                    <?php if($errors->has('email')): ?>
                                    <span class=" alert-danger"><?php echo e($errors->first('email')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-lg-6 col-sm-6 form-group">
                                    <label> Phone Number</label>
                                    <input class="form-control" type="text" value="<?php echo e((@$user_info->phone_number) ?  @$user_info->phone_number: old('phone_number')); ?>" name="phone_number" placeholder="Phone Number Here">
                                    <?php if($errors->has('phone_number')): ?>
                                    <span class=" alert-danger"><?php echo e($errors->first('phone_number')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-lg-6 col-sm-6 form-group">
                                    <label> Address</label>
                                    <input class="form-control" type="text" value="<?php echo e((@$user_info->address) ?  @$user_info->address: old('address')); ?>" name="address" placeholder="Address Here">
                                    <?php if($errors->has('address')): ?>
                                    <span class=" alert-danger"><?php echo e($errors->first('address')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-lg-6 col-sm-6 form-group">
                                    <label> Products</label>
                                    <select name="product_id[]" class="travel-style form-control" multiple>
                                    <option value="">-- select one --</option>
                                    <?php $__currentLoopData = $products->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product['id']); ?>" <?php echo e(($user_info->products->where('id',$product['id'])->count()==0)?'':'selected'); ?>><?php echo e($product['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                    
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-lg-6 col-sm-6 form-group">
                                    <label>Password</label>
                                    <input class="form-control" type="password" value="" name="password" placeholder="Password here">
                                    <?php if($errors->has('password')): ?>
                                    <span class=" alert-danger"><?php echo e($errors->first('password')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-lg-6 col-sm-6 form-group">
                                    <label>Re-password</label>
                                    <input class="form-control" type="password" value="" name="password_confirmation" placeholder="password_confirmation here">
                                    <?php if($errors->has('password_confirmation')): ?>
                                    <span class=" alert-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="col-lg-3">
                    <div class="ibox">
                        <div class="ibox-body">
                            <div class="form-group">
                                <label> Upload Image</label>
                                <input class="form-control" type="file" name="profile_image" id="image" accept="image/*" onchange="preview()">
                                <img id="frame" src="<?php echo e(Storage::url($user_info->profile_image)); ?>" width="100px"
                                                height="100px" />
                                <?php if($errors->has('profile_image')): ?>
                                    <div class="error alert-danger"><?php echo e($errors->first('profile_image')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                        <label class="ui-checkbox ui-checkbox-primary" style="margin-top: 35px;">
                                            <input type="checkbox" name="status" <?php echo e(((@$user_info->status == 1) ? 'checked' : '')); ?>>
                                            <span class="input-span"></span><strong>Publish</strong>
                                        </label>
                                    </div>
                            <div class="form-group">
                                <button class="btn btn-success" type="submit"> <span class="fa fa-send"></span> Save</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </form>
     
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function() {
    $('.travel-style').select2({
        placeholder: "Select Products",
    });
});
</script>
<script>
    function preview() {
        frame.src=URL.createObjectURL(event.target.files[0]);
    }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\shery-treding\shrey-trading\resources\views/admin/client/edit.blade.php ENDPATH**/ ?>