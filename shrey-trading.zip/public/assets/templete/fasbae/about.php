<?php include('./inc/header.php') ?>
<link rel="stylesheet" href="css/innerpage.css">
<div class="about__image">
    <img src="img/about.jpg" alt="about">
    <h2 class="about__image__heading">Delievering what you need!</h2>
</div>

<section id="about__section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="site__title">
                    <h3 class="site__title-title O A">our story</h3>
                </div>
            </div>
        </div>
        <div class="about__text">
            <p class="about__text-para">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempore quibusdam ab recusandae perspiciatis! Fugiat reiciendis possimus porro omnis consequatur dignissimos harum exercitationem saepe
                <br> excepturi asperiores, voluptas necessitatibus corrupti laudantium eius doloremque voluptatum quo amet ad cupiditate odit? Officia amet ipsa incidunt iste fugiat? Excepturi officia corporis dolore illum adipisci aliquid placeat! Aliquam saepe sed quo iste ullam veniam consequuntur ipsa?Lorem ipsum dolor sit amet consectetur adipisicing elit.
               Ab placeat quis consequuntur commodi delectus distinctio voluptates modi? Modi obcaecati rem quis maiores eos veniam aspernatur, voluptas fuga laboriosam voluptatibus. Eius, aperiam nemo! Omnis, iure aliquid molestias
               <br> architecto optio hic magnam debitis sit quibusdam maxime temporibus tempore id libero, sed modi porro quisquam consectetur maiores? Aspernatur perspiciatis cumque eaque cupiditate sequi?
            </p>
        </div>
    </div>
</section>
<?php include('./inc/footer.php') ?>