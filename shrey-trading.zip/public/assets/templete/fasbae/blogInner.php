<?php include('inc/header.php') ?>
<link rel="stylesheet" href="css/innerpage.css">

<section id="Innerbanner" style="background-image: url('img/Innerpage.jpg')">
</section>

<section id="blogInner">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <h2 class="singlePost__title">blog title 01</h2>
            </div>
            <div class="col-lg-8">
                <div class="Wrapper">
                    <div class="singlePost">
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus provident nemo facilis
                            suscipit necessitatibus, quas fuga nam nihil earum dolorum eum deleniti velit repellat sint
                            quae consequatur. Mollitia ducimus ipsa non asperiores excepturi. Quisquam, eveniet saepe,
                            amet voluptatem fuga alias minima, praesentium ab eum error commodi harum adipisci dolor
                            architecto! Nulla accusamus temporibus velit, in possimus dolores totam ipsam labore.</p>
                        <br>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam doloribus necessitatibus
                            explicabo quasi. Provident blanditiis unde numquam debitis magni ipsa, accusantium
                            voluptatum neque consequuntur sapiente laborum recusandae eveniet adipisci velit suscipit
                            dolor tenetur repellendus ipsum magnam. Et sit aliquid iure.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <img class="blog-image-img" src="img/p1.png" alt="Card image cap">
                            <div class="card-body">
                                <h2 class="card-title text-capitalize"><a href="blogInner.php">blog title 01</a>
                                </h2>
                                <p class="text-muted">16th January 2019</p>
                                <p class="card-text">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Est esse
                                    quos
                                    dolorem, sit quam temporibus dolore ex cumque! Tenetur perferendis corrupti vitae
                                    quam,
                                    voluptate numquam. Odio enim sapiente, quam numquam ex, quidem dolor placeat atque,
                                    reprehenderit sunt officiis nihil iure?</p>
                                <a href="blogInner.php" class="btn blog-button text-uppercase">more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card">
                            <img class="blog-image-img" src="img/p1.png" alt="Card image cap">
                            <div class="card-body">
                                <h2 class="card-title text-capitalize"><a href="blogInner.php">blog title 01</a>
                                </h2>
                                <p class="text-muted">16th January 2019</p>
                                <p class="card-text">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Est esse
                                    quos
                                    dolorem, sit quam temporibus dolore ex cumque! Tenetur perferendis corrupti vitae
                                    quam,
                                    voluptate numquam. Odio enim sapiente, quam numquam ex, quidem dolor placeat atque,
                                    reprehenderit sunt officiis nihil iure?</p>
                                <a href="blogInner.php" class="btn blog-button text-uppercase">more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card">
                            <img class="blog-image-img" src="img/p1.png" alt="Card image cap">
                            <div class="card-body">
                                <h2 class="card-title text-capitalize"><a href="blogInner.php">blog title 01</a>
                                </h2>
                                <p class="text-muted">16th January 2019</p>
                                <p class="card-text">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Est esse
                                    quos
                                    dolorem, sit quam temporibus dolore ex cumque! Tenetur perferendis corrupti vitae
                                    quam,
                                    voluptate numquam. Odio enim sapiente, quam numquam ex, quidem dolor placeat atque,
                                    reprehenderit sunt officiis nihil iure?</p>
                                <a href="blogInner.php" class="btn blog-button text-uppercase">more</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- <div class="row">
            <div class="col-lg-6">
                <a href="pdf/meeting.pdf" class="btn red-large-button text-white text-uppercase">download
                    1st AAERI NEPAL AGM MINUTES</a>
            </div>
        </div> -->
    </div>
</section>

<?php include('inc/footer.php') ?>