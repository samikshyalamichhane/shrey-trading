<footer class="page-footer">
    <div class="font-13"> @php echo date('Y'); @endphp © <b>Web House Nepal</b> - All rights reserved.</div>
    <a class="px-4" href="https://webhousenepal.com/" target="_blank">Designed & Developed By Web House Nepal</a>
    <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
</footer>